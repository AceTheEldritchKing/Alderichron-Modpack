The First Goat Horn Resource Pack Template
By Kloeno


Easy Method -

Replace "Call#.ogg" files with your custom sounds, and rename files to "call0" , "call1" , "call2" , "call3" , "call4" , "call5" , "call6" , "call7"
Then enable the resource pack as you normally would

.ogg file to Goat Horn key -
"call0.ogg" = "Ponder"
"call1.ogg" = "Sing"
"call2.ogg" = "Seek"
"call3.ogg" = "Feel"
"call4.ogg" = "Admire"
"call5.ogg" = "Call"
"call6.ogg" = "Yearn"
"call7.ogg" = "Dream"


FILES MUST BE .ogg FORMAT

If you wish for a Goat Horn to stay as its default sound, match the .ogg to the goat horn name and delete it.